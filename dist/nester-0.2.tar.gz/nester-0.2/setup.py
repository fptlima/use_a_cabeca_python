from setuptools import setup

setup(
    name='nester',
    version='0.2',
    description='A simple printer of nested lists',
    author='fptlima',
    author_email='ftlima@gmail.com',
    packages=['nester'],
)
